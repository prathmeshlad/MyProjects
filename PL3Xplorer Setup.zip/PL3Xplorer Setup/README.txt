********************************************************************************************************
					PL3Xplorer v1.0
				The Web Browser by Prathmesh Lad
********************************************************************************************************

--------------------
DESCRIPTION:
--------------------

PL3Xplorer (meaning Prathmesh Lad EXplorer) is a simple web browser developed to surf the internet. It provides you with
basic necessities a typical web browser should offer. You can run the browser from your start menu (by typing pl3Xplorer in
the search box) and perform basic actions like:
-go BACK
-go FORWARD
-RELOAD the web page
-STOP loading a webpage
-GO to the url entered in the address bar
-set your HOMEPAGE (initially its NULL)


---------------------------------
SYSTEM REQUIREMENTS:
---------------------------------

-D:\ partition on your storage disk
-Any processor with a minimum clock speed of 1 GHz
-Minimum 1 GB of RAM
-Windows 7 x64/x86 or higher
-An active internet connection


---------------------
INSTALLATION:
---------------------

NOTE: Before installing please make sure you have a D:\ partition on your hard disk.You can still proceed with the installation but then
you won't be able to set the homepage in the browser after installing it.

1]. Locate the "setup.exe" file.
2]. Simply run the setup and proceed to install
3]. Click Install if the "Application Install - Security Warning" window pops up
4]. Provide all permissions by clicking "Yes/Allow/Run etc." in any intermediate windows if they pop up
5]. Done. Experience the joy of surfing the Internet.



----------------------
UNINSTALLING:
----------------------

1]. Go to the control panel.
2]. Switch to Category View
3]. Under Programs, click on Uninstall a Program
4]. Locate "PL3Xplorer", right click on it and click uninstall.



----------------
FILES LIST:
----------------

PL3Xplorer creates only one single file named "log.txt" in your D:\ partition. This file will store the url of the homepage which you set in
the web browser.



-------------------
KNOWN BUG:
-------------------

-PL3Xplorer requires a D:\ partition on the hard disk which everyone might not have.
-Some webpages give script errors i.e. a "Script Error" window pops up asking the user whether to continue running scripts on that webpage.

---------------
CONTACT:
---------------

If you have any feedback, bug report, suggestions or crash reports then you may contact on the following email:
prathamesh691997@gmail.com

********************************************************************************************************

PL3Xplorer [Version 1.0]
�2017 Prathmesh Lad. All Rights Reserved.